const fs = require('fs');

export class ProductManager{
    constructor(path){
        this.path = path;
    };

    getProducts(){
        try {
            const data = fs.readFileSync(this.path)
            
            this.products = JSON.parse(data);
            console.log('Archivo leído');
        } catch (error) {
            console.error('Error al leer el archivo');
            if(error.errno === -4058) console.log('El archivo no existe');
            else console.log(error);
        }
        return this.products
    };

    getProductsByID(id){
        const idCoindence = this.products.findIndex(event => event.id === id)
        if(idCoindence === -1){
            return 'Product not found'
        }else{
            console.log('The chosen product is: ');
            return (this.products[idCoindence])
        }
        
    }

    addProduct(title, descripcion, price, thumbnail, code, stock){
        if(!title || !descripcion || !price || !thumbnail || !code || !stock ){
            // console.log('Todos los campos deben ser obligatorios');
        };

        const newProduct ={
            id: this.products.length + 1,
            title,
            descripcion,
            price,
            thumbnail,
            code,
            stock
        }

        const repeatedCode = this.products.findIndex(prod => prod.code === code)
        if(repeatedCode === -1){
            this.products.push(newProduct);
            let newProductStr = JSON.stringify(this.products, null, 2)
            fs.writeFileSync(this.path, newProductStr)
            return 'Product Added'
        }else{
            return 'Error. The product code already exists'
        }
    }

    async updateProduct(id, updatedFields){
        const idCoindence = this.products.findIndex(event => event.id === id);

        if(idCoindence === -1){
            return 'Not found';
        }else{
            try {
                let selectedProduct = this.products[idCoindence];
                Object.assign(selectedProduct,updatedFields);
                const updateProductStr = JSON.stringify(this.products,null,2);
                await fs.promises.writeFile(this.path,updateProductStr);
                console.log(this.products[idCoindence]);
                return `El producto con ID ${id} fue modificado exitosamente`
            } catch (error) {
                return `Error al actualizar el producto. Error: ${error}`
            }
        }
    }

    async deleteProduct(id){
        const idCoindence = this.products.findIndex(event => event.id === id)

        if(idCoindence === -1){
            return 'Not found'
        }else{
            this.products.splice(idCoindence, 1);
            try {
                await fs.promises.writeFile(this.path,JSON.stringify(this.products,null,2));
                return `Producto con ID ${id} eliminado correctamente`
            } catch (error) {
                return `Error al eliminar el producto. Error ${error}`
            }
        }
    }
}

